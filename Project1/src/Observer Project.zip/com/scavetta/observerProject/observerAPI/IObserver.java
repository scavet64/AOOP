package com.scavetta.observerProject.observerAPI;

public interface IObserver {
    void update (Object object);
}
